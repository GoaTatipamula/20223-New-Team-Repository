package org.firstinspires.ftc.teamcode.opmodes;

import com.pedropathing.follower.Follower;
import com.pedropathing.geometry.BezierLine;
import com.pedropathing.geometry.Pose;
import com.pedropathing.paths.PathChain;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;

import org.firstinspires.ftc.teamcode.pedroPathing.Constants;

@Autonomous(name = "Pedro Test Auto", group = "Autonomous")
public class TestAuto extends LinearOpMode {

    private Follower follower;

    // Define coordinate poses (X, Y, Heading in Radians)
    private final Pose startPose  = new Pose(0, 0, Math.toRadians(0));
    private final Pose point1     = new Pose(5, 0, Math.toRadians(0));   // 5" Forward
    private final Pose point2     = new Pose(5, 5, Math.toRadians(0));   // 5" Left
    private final Pose endPose    = new Pose(0, 0, Math.toRadians(0));   // Back to Origin

    private PathChain testPath;

    public void buildPaths() {
        testPath = follower.pathBuilder()
                .addPath(new BezierLine(startPose, point1))
                .setLinearHeadingInterpolation(startPose.getHeading(), point1.getHeading())

                .addPath(new BezierLine(point1, point2))
                .setLinearHeadingInterpolation(point1.getHeading(), point2.getHeading())

                .addPath(new BezierLine(point2, endPose))
                .setLinearHeadingInterpolation(point2.getHeading(), endPose.getHeading())
                .build();
    }

    @Override
    public void runOpMode() {
        // Initialize the follower and build paths during init
        follower = Constants.createFollower(hardwareMap);
        follower.setStartingPose(startPose);
        follower.setMaxPower(0.10);

        buildPaths();

        telemetry.addData("Status", "Initialized. Ready to start.");
        telemetry.update();

        // Wait for the driver to hit PLAY on the Driver Station
        waitForStart();

        if (isStopRequested()) return;

        // Start following the path chain
        follower.followPath(testPath, true); // true = hold position at the end of the path

        // Keep the OpMode running while the robot executes the autonomous path
        while (opModeIsActive()) {
            follower.update();

            // Print telemetry
            telemetry.addData("X", follower.getPose().getX());
            telemetry.addData("Y", follower.getPose().getY());
            telemetry.addData("Heading (Deg)", Math.toDegrees(follower.getPose().getHeading()));
            telemetry.addData("Is Busy", follower.isBusy());
            telemetry.update();
        }
    }
}